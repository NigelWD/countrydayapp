 //
//  Schedule.swift
//  WLAppleCalendar
//
//  Created by willard on 2017/9/15.
//  Copyright © 2017年 willard. All rights reserved.
//

import UIKit

struct Schedule {
    var title: String?
    var note: String?
    var startTime: Date?
    var endTime: Date?
    var categoryColor: UIColor?
}

// random events
extension Schedule {
    init(fromStartDate: Date, message:String, date:String, starttime:String, endtime:String)
    {
        
        print(date)
       
        //Changed by Rajeev for displaying correct data in calendar
        var DAY : Int? = Int()
      
        if DAY != nil
        {
        DAY = Int(date)
        }
        title = message
        note = message
        categoryColor = .red
        
       // let arrStartTime = starttime.components(separatedBy: " ")
        //let arrEndTime = endtime.components(separatedBy: " ")
        
        let dateAsStringStartTime = starttime
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "h:mm a"
        let date = dateFormatter.date(from: dateAsStringStartTime)
        let dateFormatter1 = DateFormatter()
        dateFormatter1.dateFormat = "HH:mm"
        let date24StartTime = dateFormatter1.string(from: date!)
        
        let dateAsStringEndTime = endtime
        let dateEnd = dateFormatter.date(from: dateAsStringEndTime)
        let date24EndTime = dateFormatter1.string(from: dateEnd!)
        
        //Setting start time value
        var strFinalStartTime = date24StartTime
        var intFinalStartTime = 0
        if date24StartTime.contains(":") {
            let arrSTime = date24StartTime.components(separatedBy: ":")
            strFinalStartTime = arrSTime[0]
            
            intFinalStartTime = Int(strFinalStartTime)!

            let min = Int(arrSTime[1])
            intFinalStartTime = intFinalStartTime * 60 + min!
        }
        else {
            intFinalStartTime = Int(strFinalStartTime)! * 60
        }
        
        //Setting end time value
        var strFinalEndTime = date24EndTime
        var intFinalEndTime = 0

        if date24EndTime.contains(":") {
            let arrETime = date24EndTime.components(separatedBy: ":")
            strFinalEndTime = arrETime[0]
            intFinalEndTime = Int(strFinalEndTime)!
            
            let min = Int(arrETime[1])
            intFinalEndTime = intFinalEndTime * 60 + min!
        }
        else {
            intFinalEndTime = Int(strFinalEndTime)! * 60
        }
        
        let day =  DAY! - 1
       // let hour = 16
        //print("hour\(hour)")
                
        var newDate = Calendar.current.date(byAdding: .day, value: day, to: fromStartDate)!
        // print("startDate\(startDate)")
        startTime = Calendar.current.date(byAdding: .minute, value: intFinalStartTime, to: newDate)!
        //  print("Start time\(startTime)")

        endTime = Calendar.current.date(byAdding: .minute, value: intFinalEndTime, to: newDate)!
        
    }
}


extension Schedule : Equatable {
    static func ==(lhs: Schedule, rhs: Schedule) -> Bool {
        return lhs.startTime == rhs.startTime
    }
}

extension Schedule : Comparable {
    static func <(lhs: Schedule, rhs: Schedule) -> Bool {
        return lhs.startTime! < rhs.startTime!
    }
}
