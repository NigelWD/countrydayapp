//
//  global.swift
//  Country Day App
//
//  Created by Ripul Sharma on 11/05/18.
//  Copyright © 2018 Solstice. All rights reserved.
//

import UIKit

var count_global = 0
