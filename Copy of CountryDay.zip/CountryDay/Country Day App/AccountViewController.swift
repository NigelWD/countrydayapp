//
//  AccountViewController.swift
//  Country Day App
//
//  Created by Nigel Denny on 1/27/18.
//  Copyright © 2018 Switch Tech. All rights reserved.
//

import UIKit
import Foundation
import MessageUI
import Firebase
import GoogleSignIn

class AccountViewController: UITableViewController, MFMailComposeViewControllerDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationController?.navigationBar.setBackgroundImage(UIImage(), for: .default)
        self.navigationController?.navigationBar.shadowImage = UIImage()
        self.navigationController?.navigationBar.isTranslucent = false
        self.navigationController?.view.backgroundColor = .clear
        
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if indexPath.section == 1 && indexPath.row == 1{
            print("pressed")
            let mailComposeViewController2 = configureMailController2() //Your error was in this line
            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController2, animated: true, completion: nil)
            } else {
                showMailError()
            }
        }
        if indexPath.section == 1 && indexPath.row == 0 {
            print("pressed")
            let mailComposeViewController = configureMailController()
            if MFMailComposeViewController.canSendMail() {
                self.present(mailComposeViewController, animated: true, completion: nil)
            } else {
                showMailError()
            }
        }
        if indexPath.section == 0 && indexPath.row == 0 {
            print("pressed")
            let firebaseAuth = Auth.auth()
            do {
                try firebaseAuth.signOut()
            } catch let signOutError as NSError {
                print ("Error signing out: %@", signOutError)
            }
        }
    }
    //if indexPath.section == 1 && indexPath.row == 1 {
    
    //}
    func configureMailController() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients(["SolsticeOfficialLLC@gmail.com"])
        mailComposerVC.setSubject("Suggestion: ")
        
        return mailComposerVC
    }
    func configureMailController2() -> MFMailComposeViewController {
        let mailComposerVC = MFMailComposeViewController()
        mailComposerVC.mailComposeDelegate = self
        mailComposerVC.setToRecipients(["SolsticeOfficialLLC@gmail.com"])
        mailComposerVC.setSubject("Report: ")
        
        return mailComposerVC
    }
    func showMailError() {
        let sendMailErrorAlert = UIAlertController(title: "Could not send email", message: "Your device could not send email", preferredStyle: .alert)
        let dismiss = UIAlertAction(title: "OK", style: .default, handler: nil)
        sendMailErrorAlert.addAction(dismiss)
        self.present(sendMailErrorAlert, animated: true, completion: nil)
    }
    func mailComposeController(_ controller: MFMailComposeViewController, didFinishWith: MFMailComposeResult, error: Error?){
        controller.dismiss(animated: true, completion: nil)
    }
    
    
}
