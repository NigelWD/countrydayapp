//
//  ScheduleTableViewCell.swift
//  WLAppleCalendar
//
//  Created by willard on 2017/9/18.
//  Copyright © 2017年 willard. All rights reserved.
//

import UIKit
// FIXME:
import GoogleAPIClientForREST

class ScheduleTableViewCell: UITableViewCell {

    @IBOutlet weak var categoryLine: UIView!
    @IBOutlet weak var startTimeLabel: UILabel!
    @IBOutlet weak var endTimeLabel: UILabel!

    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var noteLabel: UILabel!
   
    // FIXME:
    var schedule: Schedule!
    {
//    var schedule: GTLRCalendarQuery_EventsList! {
        didSet
        {
            
            titleLabel.text = schedule.title
            noteLabel.text =  schedule.note
            
            let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "HH:mm"
            
            // FIXME:
            // You should select needed property from the list of available options
            // I used calendarID and description as an example
//            titleLabel.text = schedule.calendarId
//            noteLabel.text = schedule.description
            
            startTimeLabel.text = dateFormatter.string(from: schedule.startTime!)
            endTimeLabel.text = dateFormatter.string(from: schedule.endTime!)
            
//            startTimeLabel.text = dateFormatter.string(from: (schedule.timeMin?.date)!)
//
//            endTimeLabel.text = dateFormatter.string(from: (schedule.timeMax?.date)!)
            
            
            // There is no property for 'categoryColor' in 'GTLRCalendarQuery_EventsList'
            // but you can use 'colorId' property in 'GTLRCalendar_Event'
            // to get color for particular event
            
            categoryLine.backgroundColor = UIColor.red//schedule.categoryColor
        }
    }
}
