//
//  GGViewController.swift
//  Country Day App
//
//  Created by Nigel Denny on 2/25/18.
//  Copyright © 2018 Solstice. All rights reserved.
//

import GoogleAPIClientForREST
import GoogleSignIn
import UIKit

class GGViewController: UIViewController, GIDSignInDelegate, GIDSignInUIDelegate {
    
    public var ArrayEvents : NSMutableArray = NSMutableArray()
    // If modifying these scopes, delete your previously saved credentials by
    // resetting the iOS simulator or uninstall the app.
    private let scopes = [kGTLRAuthScopeCalendarReadonly]
    
    private let service = GTLRCalendarService()
    let signInButton = GIDSignInButton()
    let output = UITextView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Configure Google Sign-in.
        GIDSignIn.sharedInstance().delegate = self
        GIDSignIn.sharedInstance().uiDelegate = self
        GIDSignIn.sharedInstance().scopes = scopes
        GIDSignIn.sharedInstance().clientID =
        "761108749726-jops885cmhb4ndetkcm1nk0uit59cdqp.apps.googleusercontent.com"//************.apps.googleusercontent.com"
        GIDSignIn.sharedInstance().signIn()
        // GIDSignIn.sharedInstance().signInSilently()
        
        // Add the sign-in button.
        view.addSubview(signInButton)
        
        // Add a UITextView to display output.
        output.frame = view.bounds
        output.isEditable = false
        output.contentInset = UIEdgeInsets(top: 20, left: 0, bottom: 20, right: 0)
        output.autoresizingMask = [.flexibleHeight, .flexibleWidth]
        output.isHidden = true
        view.addSubview(output);
    }
    
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
              withError error: Error!) {
        if let error = error {
            showAlert(title: "Authentication Error", message: error.localizedDescription)
            self.service.authorizer = nil
        } else {
            self.signInButton.isHidden = true
            self.output.isHidden = false
            self.service.authorizer = user.authentication.fetcherAuthorizer()
            fetchEvents()
        }
    }
    
    // Construct a query and get a list of upcoming events from the user calendar
    func fetchEvents() {
        let query = GTLRCalendarQuery_EventsList.query(withCalendarId: "primary")
        query.maxResults = 10
        query.timeMin = GTLRDateTime(date: Date())
        query.singleEvents = true
        query.orderBy = kGTLRCalendarOrderByStartTime
        service.executeQuery(
            query,
            delegate: self,
            didFinish: #selector(displayResultWithTicket(ticket:finishedWithObject:error:)))
    }
    
    // Display the start dates and event summaries in the UITextView
    @objc func displayResultWithTicket(
        ticket: GTLRServiceTicket,
        finishedWithObject response : GTLRCalendar_Events,
        error : NSError?) {
        
        if let error = error {
            showAlert(title: "Error", message: error.localizedDescription)
            return
        }
        
        var testDict = [String:String]()
        var testArr = [[String:String]]()
        if let events = response.items, !events.isEmpty {
            for event in events {
                print(event)
                let start = event.start!.dateTime ?? event.start!.date!
                let startString = DateFormatter.localizedString(
                    from: start.date,
                    dateStyle: .short,
                    timeStyle: .short)
                
                let end = event.end!.dateTime ?? event.end!.date!
                let endString = DateFormatter.localizedString(
                    from: end.date,
                    dateStyle: .short,
                    timeStyle: .short)
                
                print("start time - \(startString) And end time - \(endString)")
                
                let arrStartDateTime = startString.components(separatedBy: ",")
                let arrEndDateTime = endString.components(separatedBy: ",")
                
                if let eventName = event.summary {
                    testDict.updateValue(eventName, forKey: "message")
                }else {
                    testDict.updateValue("No title", forKey: "message")
                    
                }
                testDict.updateValue(arrStartDateTime[0], forKey: "date")
                testDict.updateValue(arrStartDateTime[1], forKey: "starttime")
                testDict.updateValue(arrEndDateTime[1], forKey: "endtime")
                
                testArr.append(testDict)
            }
        } else {
            // outputText = "No upcoming events found."
        }
        
        let datesArray = testArr.flatMap { $0["date"] } // return array of date
        var dic = [String:[[String:Any]]]() // Your required result
        datesArray.forEach {
            let dateKey = $0
            let filterArray = testArr.filter { $0["date"] == dateKey }
            dic[$0] = filterArray
            
        }
        print(dic)
        
        UserDefaults.standard.set(dic, forKey: "event")
        
        let objcalenderview = storyboard?.instantiateViewController(withIdentifier: "ViewController") as! ViewController
        self.navigationController?.pushViewController(objcalenderview, animated: true)
    }
    
    
    // Helper for showing an alert
    func showAlert(title : String, message: String) {
        let alert = UIAlertController(
            title: title,
            message: message,
            preferredStyle: UIAlertControllerStyle.alert
        )
        let ok = UIAlertAction(
            title: "OK",
            style: UIAlertActionStyle.default,
            handler: nil
        )
        alert.addAction(ok)
        present(alert, animated: true, completion: nil)
    }
}
